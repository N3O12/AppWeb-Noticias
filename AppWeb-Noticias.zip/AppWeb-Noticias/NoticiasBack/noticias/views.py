from rest_framework import viewsets
from rest_framework.parsers import MultiPartParser, FormParser
from noticias.models import Noticia, Comentario
from .serializers import NoticiaSerializer, ComentarioSerializer
from rest_framework.permissions import IsAdminUser, AllowAny, IsAuthenticated

class NoticiaViewSet(viewsets.ModelViewSet):
    queryset = Noticia.objects.all()
    serializer_class = NoticiaSerializer
    parser_classes = (MultiPartParser, FormParser)

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            self.permission_classes = [AllowAny]
        else:
            self.permission_classes = [AllowAny]
        return super().get_permissions()

class ComentarioViewSet(viewsets.ModelViewSet):
    queryset = Comentario.objects.all()
    serializer_class = ComentarioSerializer
    permission_classes = [IsAuthenticated]  # Asegurarse de que el usuario esté autenticado

    def perform_create(self, serializer):
        serializer.save(usuario=self.request.user)  # Asignar el usuario autenticado al guardar