from django.contrib import admin
from .models import Noticia, Comentario

class NoticiaAdmin(admin.ModelAdmin):
    list_display = ('id', 'titulo', 'fecha_publicacion')  # Asegúrate de incluir 'id' en list_display

class ComentarioAdmin(admin.ModelAdmin):
    list_display = ('id', 'noticia', 'contenido', 'fecha_publicacion')  # Asegúrate de incluir 'id' en list_display

admin.site.register(Noticia, NoticiaAdmin)
admin.site.register(Comentario, ComentarioAdmin)