from rest_framework import serializers
from noticias.models import Noticia, Comentario

class ComentarioSerializer(serializers.ModelSerializer):
    usuario = serializers.SerializerMethodField()

    class Meta:
        model = Comentario
        fields = '__all__'
        read_only_fields = ['usuario']  # Asegurarse de que el campo usuario sea de solo lectura

    def get_usuario(self, obj):
        return obj.usuario.username

class NoticiaSerializer(serializers.ModelSerializer):
    comentarios = ComentarioSerializer(many=True, read_only=True)  # Incluir comentarios

    class Meta:
        model = Noticia
        fields = '__all__'