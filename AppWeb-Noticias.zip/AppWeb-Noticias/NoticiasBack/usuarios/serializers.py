from rest_framework import serializers
from .models import Usuario, Rol

class RolSerializer(serializers.ModelSerializer):
    class Meta:
        model = Rol
        fields = '__all__'  # Ajusta los campos según tus necesidades

class UsuarioSerializer(serializers.ModelSerializer):
    roles = RolSerializer(many=True, required=False)  # Cambiado a required=False

    class Meta:
        model = Usuario
        fields = ['username', 'password', 'email', 'roles']
        extra_kwargs = {
            'password': {'write_only': True}
        }

    def create(self, validated_data):
        roles_data = validated_data.pop('roles', [])  # Cambiado para manejar la ausencia de 'roles'
        usuario = Usuario.objects.create_user(**validated_data)
        for rol_data in roles_data:
            Rol.objects.create(usuario=usuario, **rol_data)
        return usuario