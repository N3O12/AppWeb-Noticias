from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import Usuario, Rol
from .serializers import UsuarioSerializer, RolSerializer
from rest_framework.permissions import AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework.views import APIView
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views import View
import json
from rest_framework.permissions import IsAuthenticated
from django.http import JsonResponse
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework.permissions import IsAuthenticated

class CustomTokenObtainPairView(TokenObtainPairView):
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        user = authenticate(username=request.data['username'], password=request.data['password'])
        if user:
            response.data['is_superuser'] = user.is_superuser
            if user.is_superuser:
                response.data['redirect_url'] = 'http://localhost:4200/noticias-admin'
            else:
                response.data['redirect_url'] = 'http://localhost:4200/noticias'
        print('Respuesta del servidor:', response.data)  # Línea de depuración
        return Response(response.data)

class UsuarioViewSet(viewsets.ModelViewSet):
    queryset = Usuario.objects.all()
    serializer_class = UsuarioSerializer

    @action(detail=False, methods=['post'], permission_classes=[AllowAny])
    def registro(self, request):
        print("Datos recibidos:", request.data)  # Línea de depuración
        serializer = UsuarioSerializer(data=request.data)
        if serializer.is_valid():
            usuario = serializer.save()
            usuario.set_password(request.data['password'])
            usuario.save()
            refresh = RefreshToken.for_user(usuario)
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            }, status=status.HTTP_201_CREATED)
        print("Errores de serialización:", serializer.errors)  # Línea de depuración
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class RolViewSet(viewsets.ModelViewSet):
    queryset = Rol.objects.all()
    serializer_class = RolSerializer

class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            refresh_token = request.data["refresh_token"]
            token = RefreshToken(refresh_token)
            token.blacklist()
            logout(request)
            return Response(status=status.HTTP_205_RESET_CONTENT)
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)

@method_decorator(csrf_exempt, name='dispatch')
class LoginView(View):
    def post(self, request, *args, **kwargs):
        data = json.loads(request.body)
        username = data.get('username')
        password = data.get('password')
        # Aquí va la lógica de autenticación
        if username == 'xd' and password == 'xd':
            return JsonResponse({'message': 'Login successful'})
        return JsonResponse({'message': 'Invalid credentials'}, status=401)
