from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import UsuarioViewSet, RolViewSet, LogoutView, CustomTokenObtainPairView, LoginView

urlpatterns = [
    path('token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('login/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),  # Usar CustomTokenObtainPairView para el login
    path('logout/', LogoutView.as_view(), name='logout'),
    path('registro/', UsuarioViewSet.as_view({'post': 'registro'}), name='registro'),
    path('roles/', RolViewSet.as_view({'get': 'list'}), name='roles_list'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    
]
