from django.urls import path
from . import views

urlpatterns = [
    path('api/noticias/<int:noticia_id>/comentarios/', views.crear_comentario, name='crear_comentario'),
]