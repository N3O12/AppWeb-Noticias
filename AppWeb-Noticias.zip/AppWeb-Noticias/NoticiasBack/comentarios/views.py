from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Comentario
from .serializers import ComentarioSerializer

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def crear_comentario(request, noticia_id):
    if request.method == 'POST':
        data = request.data.copy()
        data['noticia'] = noticia_id
        data['usuario'] = request.user.id  # Asignar el usuario autenticado al comentario
        print('Usuario autenticado:', request.user.id)  # Depuración
        print('Datos recibidos en el backend:', data)  # Depuración
        serializer = ComentarioSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        print('Errores de validación:', serializer.errors)  # Depuración
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)