from django.db import migrations, models
from django.conf import settings

def handle_null_usuario(apps, schema_editor):
    Comentario = apps.get_model('comentarios', 'Comentario')
    User = apps.get_model(settings.AUTH_USER_MODEL)
    default_user = User.objects.first()  # O selecciona un usuario específico
    Comentario.objects.filter(usuario__isnull=True).update(usuario=default_user)

class Migration(migrations.Migration):

    dependencies = [
        ('comentarios', '0016_alter_comentario_usuario'),
    ]

    operations = [
        migrations.RunPython(handle_null_usuario),
    ]