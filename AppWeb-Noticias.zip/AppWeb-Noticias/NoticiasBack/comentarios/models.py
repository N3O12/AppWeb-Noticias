from django.db import models
from django.conf import settings

class Comentario(models.Model):
    noticia = models.ForeignKey('noticias.Noticia', related_name='comentarios_comentarios', on_delete=models.CASCADE)
    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='comentarios_comentarios', on_delete=models.CASCADE)
    contenido = models.TextField()
    fecha_publicacion = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.contenido