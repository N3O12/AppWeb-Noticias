from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/usuarios/', include('usuarios.urls')),
    path('api/', include('noticias.urls')),  # Asegúrate de incluir esta línea
    path('api/noticiasAdmin/', include('noticiasAdmin.urls')),
    path('api/comentarios/', include('comentarios.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)