import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class NoticiasService {
    private baseUrl = 'http://localhost:8000/api/noticias/';

    constructor(private http: HttpClient) { }

    getNoticias(): Observable<any> {
        return this.http.get(this.baseUrl);
    }
}
