import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { MessageService } from 'primeng/api';

@Component({
    selector: 'app-registro',
    templateUrl: './registro.component.html',
    styleUrls: ['./registro.component.css']
})
export class RegistroComponent {
    usuario = { username: '', password: '', email: '' };

    constructor(
        private authService: AuthService,
        private router: Router,
        private messageService: MessageService
    ) {}

    registrar() {
        this.authService.registro(this.usuario).subscribe({
            next: (response) => {
                console.log('Registro exitoso', response);
                // La notificación de éxito ya se maneja en el servicio
            },
            error: (errorMessage) => {
                console.error('Error al registrarse', errorMessage);
                // La notificación de error ya se maneja en el servicio
            }
        });
    }
}