import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service'; // Asegúrate de importar AuthService correctamente

@Component({
    selector: 'app-navegacion',
    templateUrl: './navegacion.component.html',
    styleUrls: ['./navegacion.component.css']
})
export class NavegacionComponent implements OnInit {

    isSuperuser: boolean = false;
    isLoggedIn: boolean = false;

    constructor(private router: Router, private authService: AuthService) {}

    ngOnInit() {
        this.authService.isLoggedIn().subscribe(loggedIn => {
            this.isLoggedIn = loggedIn;
        });
        this.authService.isSuperuserObservable().subscribe(isSuperuser => {
            this.isSuperuser = isSuperuser;
        });
    }

    logout() {
        this.authService.logout();
    }
}