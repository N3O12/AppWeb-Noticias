import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NoticiaService } from '../noticia.service';
import { MessageService } from 'primeng/api';

@Component({
    selector: 'app-noticias',
    templateUrl: './noticias.component.html',
    styleUrls: ['./noticias.component.css']
})
export class NoticiasComponent implements OnInit {
    noticias: any[] = [];

    constructor(private noticiaService: NoticiaService, private router: Router, private messageService: MessageService) {}

    ngOnInit() {
        this.cargarNoticias();
    }

    cargarNoticias() {
        this.noticiaService.getNoticias().subscribe({
            next: (data) => {
                this.noticias = data.sort((a, b) => new Date(b.fecha_publicacion).getTime() - new Date(a.fecha_publicacion).getTime());
            },
            error: (error) => {
                console.error('Error al cargar las noticias:', error);
                this.messageService.add({ severity: 'error', summary: 'Error', detail: error });
            }
        });
    }

    verNoticia(id: number) {
        this.router.navigate(['/noticia', id]);
    }
}