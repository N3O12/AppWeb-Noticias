import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { AdminGuard } from './guards/admin.guard';
import { LoginComponent } from './login/login.component';
import { NoticiasComponent } from './noticias/noticias.component';
import { NoticiasAdminComponent } from './noticias-admin/noticias-admin.component';
import { ComentariosAdminComponent } from './comentarios-admin/comentarios-admin.component';
import { RegistroComponent } from './registro/registro.component';
import { NoticiaDetalleComponent } from './noticia-detalle/noticia-detalle.component';

const routes: Routes = [
    { path: 'login', component: LoginComponent, data: { animation: 'LoginPage' } },
    { path: 'registro', component: RegistroComponent, data: { animation: 'RegistroPage' } },
    { path: 'noticias', component: NoticiasComponent, data: { animation: 'NoticiasPage' } },
    { path: 'noticia/:id', component: NoticiaDetalleComponent, data: { animation: 'NoticiaDetallePage' } },
    { path: 'noticias-admin', component: NoticiasAdminComponent, canActivate: [AdminGuard], data: { animation: 'NoticiasAdminPage' } },
    { path: 'comentarios-admin', component: ComentariosAdminComponent, canActivate: [AdminGuard], data: { animation: 'ComentariosAdminPage' } },
    { path: '', redirectTo: '/noticias', pathMatch: 'full' },
    { path: '**', redirectTo: '/noticias' }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }