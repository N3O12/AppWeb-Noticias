import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistroComponent } from './registro/registro.component';
import { NoticiasComponent } from './noticias/noticias.component';
import { ComentariosComponent } from './comentarios/comentarios.component';
import { NavegacionComponent } from './navegacion/navegacion.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { CardModule } from 'primeng/card';
import { ToastModule } from 'primeng/toast';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MessageService, ConfirmationService } from 'primeng/api';
import { AuthInterceptor } from './auth-interceptor.service';
import { NoticiasAdminComponent } from './noticias-admin/noticias-admin.component';
import { ComentariosAdminComponent } from './comentarios-admin/comentarios-admin.component';
import { MenubarModule } from 'primeng/menubar';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { RippleModule } from 'primeng/ripple';
import { NoticiaDetalleComponent } from './noticia-detalle/noticia-detalle.component';
import { ConfirmDialogModule } from 'primeng/confirmdialog'; // Importar ConfirmDialogModule

@NgModule({
    declarations: [
        AppComponent,
        LoginComponent,
        RegistroComponent,
        NoticiasComponent,
        ComentariosComponent,
        NavegacionComponent,
        NoticiasAdminComponent,
        ComentariosAdminComponent,
        NoticiaDetalleComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        HttpClientModule,
        FormsModule,
        ButtonModule,
        InputTextModule,
        MenubarModule,
        CardModule,
        ToastModule,
        BrowserAnimationsModule,
        TableModule,
        DialogModule,
        InputTextareaModule,
        RippleModule,
        ConfirmDialogModule // Agregar ConfirmDialogModule
    ],
    providers: [
        MessageService,
        ConfirmationService, // Agregar ConfirmationService
        { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }