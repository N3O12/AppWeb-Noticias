import { Component, Input, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
    selector: 'app-comentarios',
    templateUrl: './comentarios.component.html',
    styleUrls: ['./comentarios.component.css']
})
export class ComentariosComponent implements OnInit {
    @Input() noticiaId!: number;  // Añadir el operador de aserción no nula
    comentarios: any[] = [];
    nuevoComentario: any = { contenido: '' };

    constructor(private http: HttpClient) {}

    ngOnInit(): void {
        this.cargarComentarios();
    }

    cargarComentarios() {
        this.http.get(`http://localhost:8000/api/noticias/${this.noticiaId}/comentarios/`)
            .subscribe(
                (data: any) => {
                    this.comentarios = data;
                },
                error => {
                    console.error('Error al cargar los comentarios', error);
                }
            );
    }

    isLoggedIn(): boolean {
        return !!localStorage.getItem('access_token');
    }

    crearComentario() {
        const token = localStorage.getItem('access_token');
        const headers = new HttpHeaders({
            'Authorization': `Bearer ${token}`
        });
        const comentarioData = {
            ...this.nuevoComentario
        };
        console.log('Datos del comentario enviados:', comentarioData);  // Depuración
        this.http.post(`http://localhost:8000/api/noticias/${this.noticiaId}/comentarios/`, comentarioData, { headers })
            .subscribe(
                (data: any) => {
                    this.comentarios.push(data);
                    this.nuevoComentario.contenido = '';
                },
                error => {
                    console.error('Error al crear el comentario', error);
                }
            );
    }
}