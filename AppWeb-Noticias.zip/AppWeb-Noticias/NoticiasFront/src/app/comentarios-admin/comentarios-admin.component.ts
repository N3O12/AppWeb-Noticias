import { Component, OnInit } from '@angular/core';
import { ComentariosService } from '../comentarios.service';
import { MessageService, ConfirmationService } from 'primeng/api';

@Component({
    selector: 'app-comentarios-admin',
    templateUrl: './comentarios-admin.component.html',
    styleUrls: ['./comentarios-admin.component.css']
})
export class ComentariosAdminComponent implements OnInit {
    comentarios: any[] = [];
    comentarioEditado: any = null;

    constructor(
        private comentariosService: ComentariosService,
        private messageService: MessageService,
        private confirmationService: ConfirmationService // Inyectar ConfirmationService
    ) {}

    ngOnInit() {
        this.cargarComentarios();
    }

    cargarComentarios() {
        this.comentariosService.getComentarios().subscribe({
            next: (data) => {
                console.log(data); // Verifica que los datos contengan el campo noticia
                this.comentarios = data;
            },
            error: (error) => {
                console.error('Error al cargar los comentarios:', error);
                this.messageService.add({ severity: 'error', summary: 'Error', detail: error });
            }
        });
    }

    confirmarEliminacion(id: number) {
        this.confirmationService.confirm({
            message: '¿Estás seguro de que deseas eliminar este comentario?',
            header: 'Confirmar Eliminación',
            icon: 'pi pi-exclamation-triangle',
            acceptLabel: 'Sí',
            rejectLabel: 'No',
            acceptButtonStyleClass: 'p-button-danger', // Cambiar el color del botón "Sí" a rojo
            accept: () => {
                this.eliminarComentario(id);
            }
        });
    }

    eliminarComentario(id: number) {
        this.comentariosService.deleteComentario(id).subscribe({
            next: () => {
                this.cargarComentarios();
                this.messageService.add({ severity: 'success', summary: 'Comentario eliminado', detail: 'El comentario ha sido eliminado con éxito.' });
            },
            error: (error) => {
                console.error('Error al eliminar el comentario:', error);
                this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Hubo un error al eliminar el comentario.' });
            }
        });
    }

    editarComentario(comentario: any) {
        this.comentarioEditado = { ...comentario };
    }

    guardarComentario() {
        if (this.comentarioEditado) {
            this.comentariosService.putComentario(this.comentarioEditado, this.comentarioEditado.id).subscribe({
                next: () => {
                    this.cargarComentarios();
                    this.comentarioEditado = null;
                    this.messageService.add({ severity: 'success', summary: 'Comentario editado', detail: 'El comentario ha sido editado con éxito.' });
                },
                error: (error) => {
                    console.error('Error al editar el comentario:', error);
                    this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Hubo un error al editar el comentario.' });
                }
            });
        }
    }

    cancelarEdicion() {
        this.comentarioEditado = null;
    }
}