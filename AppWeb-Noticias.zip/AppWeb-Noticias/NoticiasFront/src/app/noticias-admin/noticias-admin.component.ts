import { Component, OnInit } from '@angular/core';
import { NoticiaService } from '../noticia.service';
import { MessageService, ConfirmationService } from 'primeng/api';

@Component({
    selector: 'app-noticias-admin',
    templateUrl: './noticias-admin.component.html',
    styleUrls: ['./noticias-admin.component.css']
})
export class NoticiasAdminComponent implements OnInit {
    nuevaNoticia: any = {};
    noticias: any[] = [];
    visible: boolean = false;
    editVisible: boolean = false;
    noticiaSeleccionada: any = {};
    imagenEliminada: boolean = false;
    videoEliminado: boolean = false;

    constructor(
        private noticiaService: NoticiaService,
        private messageService: MessageService,
        private confirmationService: ConfirmationService // Inyectar ConfirmationService
    ) {}

    ngOnInit() {
        this.cargarNoticias();
    }

    cargarNoticias() {
        this.noticiaService.getNoticias().subscribe({
            next: (data) => {
                this.noticias = data;
            },
            error: (error) => {
                console.error('Error al cargar las noticias:', error);
                this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error al cargar las noticias' });
            }
        });
    }

    mostrarDialogo() {
        this.visible = true;
        this.nuevaNoticia = {};
    }

    guardaNuevaNoticia() {
        const formData = new FormData();
        formData.append('titulo', this.nuevaNoticia.titulo);
        formData.append('contenido', this.nuevaNoticia.contenido);
        formData.append('fecha_publicacion', this.nuevaNoticia.fecha_publicacion);
        if (this.nuevaNoticia.imagen) {
            formData.append('imagen', this.nuevaNoticia.imagen);
        }
        if (this.nuevaNoticia.video) {
            formData.append('video', this.nuevaNoticia.video);
        }

        this.noticiaService.postNoticia(formData).subscribe({
            next: () => {
                this.cargarNoticias();
                this.visible = false;
                this.messageService.add({ severity: 'success', summary: 'Éxito', detail: 'Noticia creada exitosamente' });
            },
            error: (error) => {
                console.error('Error al guardar la nueva noticia:', error);
                this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error al guardar la nueva noticia' });
            }
        });
    }

    onFileChange(event: any, type: string, noticia?: any) {
        if (event.target.files.length > 0) {
            const file = event.target.files[0];
            if (type === 'imagen') {
                if (noticia) {
                    noticia.imagen = file;
                } else {
                    this.nuevaNoticia.imagen = file;
                }
            } else if (type === 'video') {
                if (noticia) {
                    noticia.video = file;
                } else {
                    this.nuevaNoticia.video = file;
                }
            }
        }
    }

    editarNoticia(noticia: any) {
        this.noticiaSeleccionada = { ...noticia };
        this.editVisible = true;
        this.imagenEliminada = false;
        this.videoEliminado = false;
    }

    cambiarImagen(type: string) {
        const input = document.createElement('input');
        input.type = 'file';
        input.onchange = (event: any) => this.onFileChange(event, type, this.noticiaSeleccionada);
        input.click();
    }

    eliminarImagen(type: string) {
        if (type === 'imagen') {
            this.noticiaSeleccionada.imagen = null;
            this.imagenEliminada = true;
        } else if (type === 'video') {
            this.noticiaSeleccionada.video = null;
            this.videoEliminado = true;
        }
    }

    confirmarEliminacion(noticia: any) {
        this.confirmationService.confirm({
            message: '¿Estás seguro de que deseas eliminar esta noticia?',
            header: 'Confirmar Eliminación',
            icon: 'pi pi-exclamation-triangle',
            acceptLabel: 'Sí',
            rejectLabel: 'No',
            acceptButtonStyleClass: 'p-button-danger', // Cambiar el color del botón "Sí" a rojo
            accept: () => {
                this.eliminarNoticia(noticia);
            }
        });
    }

    eliminarNoticia(noticia: any) {
        this.noticiaService.deleteNoticia(noticia.id).subscribe({
            next: () => {
                this.cargarNoticias();
                this.messageService.add({ severity: 'success', summary: 'Éxito', detail: 'Noticia eliminada exitosamente' });
            },
            error: (error) => {
                console.error('Error al eliminar la noticia:', error);
                this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error al eliminar la noticia' });
            }
        });
    }

    onRowEditSave(noticia: any) {
        const formData = new FormData();
        formData.append('titulo', noticia.titulo);
        formData.append('contenido', noticia.contenido);
        formData.append('fecha_publicacion', noticia.fecha_publicacion);

        if (noticia.imagen && typeof noticia.imagen !== 'string') {
            formData.append('imagen', noticia.imagen);
        } else if (this.imagenEliminada) {
            formData.append('imagen', '');
        }

        if (noticia.video && typeof noticia.video !== 'string') {
            formData.append('video', noticia.video);
        } else if (this.videoEliminado) {
            formData.append('video', '');
        }

        // Verificar los datos antes de enviarlos
        formData.forEach((value, key) => {
            console.log(key + ', ' + value);
        });

        this.noticiaService.putNoticia(formData, noticia.id).subscribe({
            next: () => {
                this.cargarNoticias();
                this.editVisible = false;
                this.messageService.add({ severity: 'success', summary: 'Éxito', detail: 'Noticia editada exitosamente' });
            },
            error: (error) => {
                console.error('Error al guardar la noticia editada:', error);
                this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error al guardar la noticia editada' });
            }
        });
    }
}