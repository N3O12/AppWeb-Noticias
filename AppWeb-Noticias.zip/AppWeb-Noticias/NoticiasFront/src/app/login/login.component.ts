import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { MessageService } from 'primeng/api';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent {
    credenciales = { username: '', password: '' };

    constructor(
        private authService: AuthService,
        private router: Router,
        private messageService: MessageService
    ) {}

    iniciarSesion() {
        this.authService.login(this.credenciales).subscribe({
            next: (response) => {
                console.log('Inicio de sesión exitoso', response);  // Línea de depuración
                this.messageService.add({ severity: 'success', summary: 'Éxito', detail: 'Inicio de sesión exitoso' });
                if (response.is_superuser) {
                    this.router.navigate(['/noticias-admin']);
                } else {
                    this.router.navigate(['/noticias']);
                }
            },
            error: (errorMessage) => {
                console.error('Error al iniciar sesión', errorMessage);
                this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Credenciales incorrectas' });  // Línea de notificación de error
            }
        });
    }
}