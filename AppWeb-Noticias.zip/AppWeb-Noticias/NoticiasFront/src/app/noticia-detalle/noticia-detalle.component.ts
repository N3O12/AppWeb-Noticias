import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NoticiaService } from '../noticia.service';
import { ComentariosService } from '../comentarios.service';
import { AuthService } from '../auth.service';
import { MessageService } from 'primeng/api';

@Component({
    selector: 'app-noticia-detalle',
    templateUrl: './noticia-detalle.component.html',
    styleUrls: ['./noticia-detalle.component.css']
})
export class NoticiaDetalleComponent implements OnInit {
    noticia: any = { comentarios: [] };  // Inicializar comentarios como un array vacío
    isLoggedIn: boolean = false;
    comentario: string = '';
    username: string = '';  // Variable para almacenar el nombre de usuario

    constructor(
        private route: ActivatedRoute,
        private noticiaService: NoticiaService,
        private comentariosService: ComentariosService,
        private authService: AuthService,
        private messageService: MessageService
    ) {}

    ngOnInit() {
        const id = this.route.snapshot.paramMap.get('id');
        if (id) {
            this.cargarNoticia(parseInt(id, 10));
        }
        this.authService.isLoggedIn().subscribe(isLoggedIn => {
            this.isLoggedIn = isLoggedIn;
            if (isLoggedIn) {
                this.username = this.authService.getUsername();  // Obtener el nombre de usuario
            }
        });
    }

    cargarNoticia(id: number) {
        this.noticiaService.getNoticia(id).subscribe({
            next: (data) => {
                this.noticia = data;
                if (!this.noticia.comentarios) {
                    this.noticia.comentarios = [];  // Asegurarse de que comentarios esté inicializado
                }
            },
            error: (error) => {
                console.error('Error al cargar la noticia:', error);
                this.messageService.add({ severity: 'error', summary: 'Error', detail: error });
            }
        });
    }

    agregarComentario() {
        if (this.comentario.trim()) {
            const nuevoComentario = {
                noticia: this.noticia.id,
                contenido: this.comentario,
                fecha_publicacion: new Date(),
                usuario: this.username  // Añadir el nombre de usuario al comentario
            };
            this.comentariosService.postComentario(nuevoComentario).subscribe({
                next: (data) => {
                    this.noticia.comentarios.push(data);
                    this.comentario = '';
                    this.messageService.add({ severity: 'success', summary: 'Comentario añadido', detail: 'Tu comentario ha sido añadido con éxito.' });
                },
                error: (error) => {
                    console.error('Error al añadir el comentario:', error);
                    this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Hubo un error al añadir tu comentario.' });
                }
            });
        }
    }
}