import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthService } from './auth.service';

@Injectable({
    providedIn: 'root'
})
export class ComentariosService {
    private comentariosUrl = 'http://localhost:8000/api/comentarios/';

    constructor(private http: HttpClient, private authService: AuthService) {}

    postComentario(comentario: any): Observable<any> {
        const headers = new HttpHeaders({
            'Authorization': `Bearer ${this.authService.getAccessToken()}`
        });
        return this.http.post<any>(this.comentariosUrl, comentario, { headers }).pipe(
            catchError(this.handleError)
        );
    }

    getComentarios(): Observable<any[]> {
        return this.http.get<any[]>(this.comentariosUrl).pipe(
            catchError(this.handleError)
        );
    }

    deleteComentario(id: number): Observable<void> {
        const headers = new HttpHeaders({
            'Authorization': `Bearer ${this.authService.getAccessToken()}`
        });
        return this.http.delete<void>(`${this.comentariosUrl}${id}/`, { headers }).pipe(
            catchError(this.handleError)
        );
    }

    putComentario(comentario: any, id: number): Observable<void> {
        const headers = new HttpHeaders({
            'Authorization': `Bearer ${this.authService.getAccessToken()}`
        });
        return this.http.put<void>(`${this.comentariosUrl}${id}/`, comentario, { headers }).pipe(
            catchError(this.handleError)
        );
    }

    private handleError(error: HttpErrorResponse) {
        let errorMessage = 'Unknown error!';
        if (error.error instanceof ErrorEvent) {
            errorMessage = `Error: ${error.error.message}`;
        } else {
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);
    }
}