import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Noticia } from '../models/noticia';

@Injectable({
    providedIn: 'root'
})
export class NoticiaService {
    private baseUrl = 'http://localhost:8000/api/noticias/';

    constructor(private http: HttpClient) {}

    getNoticias(): Observable<Noticia[]> {
        return this.http.get<Noticia[]>(this.baseUrl).pipe(
            catchError(this.handleError)
        );
    }

    getNoticia(id: number): Observable<Noticia> {
        return this.http.get<Noticia>(`${this.baseUrl}${id}/`).pipe(
            catchError(this.handleError)
        );
    }

    postNoticia(noticia: FormData): Observable<Noticia> {
        return this.http.post<Noticia>(this.baseUrl, noticia).pipe(
            catchError(this.handleError)
        );
    }

    putNoticia(noticia: FormData, id: number): Observable<void> {
        return this.http.put<void>(`${this.baseUrl}${id}/`, noticia).pipe(
            catchError(this.handleError)
        );
    }

    deleteNoticia(id: number): Observable<void> {
        return this.http.delete<void>(`${this.baseUrl}${id}/`).pipe(
            catchError(this.handleError)
        );
    }

    private handleError(error: HttpErrorResponse) {
        let errorMessage = 'Unknown error!';
        if (error.error instanceof ErrorEvent) {
            // Client-side errors
            errorMessage = `Error: ${error.error.message}`;
        } else {
            // Server-side errors
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);
    }
}