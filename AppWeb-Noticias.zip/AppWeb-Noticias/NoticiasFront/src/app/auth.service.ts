import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';

@Injectable({
    providedIn: 'root'
})
export class AuthService {

    private baseUrl = 'http://localhost:8000/api';
    private loggedIn = new BehaviorSubject<boolean>(this.hasToken());
    private isSuperuserSubject = new BehaviorSubject<boolean>(this.isSuperuser());

    constructor(private http: HttpClient, private router: Router, private messageService: MessageService) {}

    registro(usuario: any): Observable<any> {
        return this.http.post(`${this.baseUrl}/usuarios/registro/`, usuario).pipe(
            tap(() => {
                this.messageService.add({ severity: 'success', summary: 'Éxito', detail: 'Registrado exitosamente' });
                this.router.navigate(['/login']); // Redirigir a la página de login después del registro
            }),
            catchError((error: HttpErrorResponse) => {
                let errorMessage = 'Error al registrarse';
                if (error.error instanceof ErrorEvent) {
                    // Error del lado del cliente
                    errorMessage = `Error: ${error.error.message}`;
                } else {
                    // Error del lado del servidor
                    if (error.status === 400) {
                        errorMessage = 'Error al registrarse';
                    }
                }
                this.messageService.clear(); // Limpiar notificaciones anteriores
                this.messageService.add({ severity: 'error', summary: 'Error', detail: errorMessage });
                return throwError(errorMessage);
            })
        );
    }

    login(credenciales: any): Observable<any> {
        return this.http.post<any>(`${this.baseUrl}/usuarios/login/`, credenciales).pipe(
            tap((response: any) => {
                console.log('Respuesta del servidor:', response);  // Línea de depuración
                localStorage.setItem('access_token', response.access);
                localStorage.setItem('refresh_token', response.refresh);
                localStorage.setItem('is_superuser', response.is_superuser ? 'true' : 'false');
                localStorage.setItem('username', credenciales.username);  // Guardar el nombre de usuario
                this.loggedIn.next(true);
                this.isSuperuserSubject.next(response.is_superuser);
            }),
            catchError(this.handleError.bind(this))
        );
    }

    logout() {
        localStorage.removeItem('access_token');
        localStorage.removeItem('refresh_token');
        localStorage.removeItem('is_superuser');
        localStorage.removeItem('username');  // Eliminar el nombre de usuario
        this.loggedIn.next(false);
        this.isSuperuserSubject.next(false);
        this.router.navigate(['/login']).then(() => {
            this.messageService.add({ severity: 'info', summary: 'Cierre de sesión', detail: 'Cierre de sesión exitoso. Lamentamos que vayas.', life: 3000 });
        });
    }

    isLoggedIn(): Observable<boolean> {
        return this.loggedIn.asObservable();
    }

    isSuperuser(): boolean {
        return localStorage.getItem('is_superuser') === 'true';
    }

    isSuperuserObservable(): Observable<boolean> {
        return this.isSuperuserSubject.asObservable();
    }

    getAccessToken(): string {
        return localStorage.getItem('access_token')!;
    }

    getUsername(): string {
        return localStorage.getItem('username')!;  // Obtener el nombre de usuario
    }

    private hasToken(): boolean {
        return !!localStorage.getItem('access_token');
    }

    private handleError(error: HttpErrorResponse) {
        let errorMessage = 'Error de autenticación';
        if (error.error instanceof ErrorEvent) {
            // Error del lado del cliente
            errorMessage = `Error: ${error.error.message}`;
        } else {
            // Error del lado del servidor
            if (error.status === 401) {
                errorMessage = 'Error de autenticación';
            }
        }
        this.messageService.clear(); // Limpiar notificaciones anteriores
        this.messageService.add({ severity: 'error', summary: 'Error', detail: errorMessage });
        return throwError(errorMessage);
    }
}