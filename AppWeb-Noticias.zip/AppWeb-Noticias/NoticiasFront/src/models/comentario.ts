export interface Comentario {
    id: number;
    noticiaId: number;
    usuario: string;
    contenido: string;
    fecha_publicacion: string;
}