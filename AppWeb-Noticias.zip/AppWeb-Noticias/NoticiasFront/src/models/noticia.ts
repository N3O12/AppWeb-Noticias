export interface Noticia {
    id: number;
    titulo: string;
    contenido: string;
    fecha_publicacion: string; // Asegúrate de que esta propiedad exista
    imagen?: string;
    video?: string;
    descripcion?: string;
}